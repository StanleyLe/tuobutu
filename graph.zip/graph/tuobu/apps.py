from django.apps import AppConfig


class TuobuConfig(AppConfig):
    name = 'tuobu'
